const cloudinary = require("../config/cloudinary");
const fs = require("fs/promises");

const uploadToCloudinary = async (
  filePath,
  folder,
  resourceType = "auto"
) => {
  if (!filePath) {
    throw new Error("File path is required");
  }

  try {
    const options = {
      folder,
      resource_type: resourceType,
    };

    // Cloudinary's large-upload API is required for large video files.
    // Keep the existing provider/folder architecture; only select the
    // provider's chunked API when the uploaded resource is a video.
    const result = resourceType === "video"
      ? await cloudinary.uploader.upload_large(filePath, {
          ...options,
          chunk_size: 20 * 1024 * 1024,
        })
      : await cloudinary.uploader.upload(filePath, options);

    await fs.unlink(filePath).catch(() => {});

    return result;
  } catch (error) {
    await fs.unlink(filePath).catch(() => {});

    console.error("Cloudinary Upload Error:", error.message);

    throw error;
  }
};

module.exports = uploadToCloudinary;